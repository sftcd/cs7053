char *format_sha1_hash(unsigned char *hash);
